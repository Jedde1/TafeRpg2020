﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class Button : MonoBehaviour
//{
//    public Vector2 scr;
//    // Start is called before the first frame update
//    void Start()
//    {
        
//    }

//    // Update is called once per frame
//    void Update()
//    {
        
//    }
//    private void OnGUI()
//    {
//        scr = new Vector2(Screen.width / 16, Screen.height / 9);

//        if(GUI.Box(new Rect(7.5f * scr.x, 4.5f, scr.y, 1 * scr.x, 1 * scr.y)))
//        {

//        }
        
//    }
//}
