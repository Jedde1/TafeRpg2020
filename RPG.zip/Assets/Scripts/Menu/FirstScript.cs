﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FirstScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    //Custom Void for SceneChange
    public void ChangeScene(int sceneId)
    {
        //Shows in console to test
        Debug.Log("Fuck My Life");
        //Changes scene depending on Scene ID
        SceneManager.LoadScene(sceneId);
    }

    public void QuitGame()
    {
        //Quits Play Mode in Editor
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
        //If the game is built it will close the app
        Application.Quit();
    }
}
