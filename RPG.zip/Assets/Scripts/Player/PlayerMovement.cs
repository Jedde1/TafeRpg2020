﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]

public class PlayerMovement : MonoBehaviour
{
    [Header("Phisics")]
    public CharacterController controller;
    public float gravity = 20f;
    [Header("Movement Variables")]
    public float walkSpeed = 10f;
    public float jumpSpeed = 8f;
    public float crouchSpeed = 5f;
    public float sprintSpeed = 15f;


    private Vector3 _moveDir;

    // Start is called before the first frame update
    void Start()
    {
        controller = gameObject.GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (controller.isGrounded)
        {
            //Move();
            _moveDir = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

            _moveDir *= walkSpeed;

            if (Input.GetButton("Jump"))
            {
                _moveDir.y = jumpSpeed;
            }
        }
        _moveDir.y -= gravity * Time.deltaTime;
        controller.Move(_moveDir * Time.deltaTime);
    }
  
}





/*
  private void Move()
  {
      moveDir = transform.TransformDirection(new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")) * walkSpeed);

      moveDir = gravity * Time.deltaTime;
      controller.Move(moveDir * Time.deltaTime);
  }
  */
