﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mouselook : MonoBehaviour
{
    public enum RotationAxis
    {
        MouseH,
        MouseV
    }
    [Header("Rotation Variables")]
    public RotationAxis axis = RotationAxis.MouseH;
    [Range(0, 200)]
    public float sensitivity = 100f;
    public float minY = -60, maxY = 60;
    private float _rotY;

    // Start is called before the first frame update
    void Start()
    {
        if (GetComponent<Rigidbody>())
        {
            GetComponent<Rigidbody>().freezeRotation = true;
        }
        if (GetComponent<Camera>())
        {
            axis = RotationAxis.MouseV;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(axis == RotationAxis.MouseH)
        {
            transform.Rotate(0, Input.GetAxis("Mouse X") * sensitivity * Time.deltaTime, 0);
        }
        else //MouseV
        {
            //transform.Rotate(Input.GetAxis("Mouse Y") * sensitivity * Time.deltaTime, 0 , 0);
        }
    }
}
